<?php

namespace App\Repositories;

class Constants {

    const USERS_PER_PAGE = 10;
    const COMMENTS_PER_PAGE = 6;
    const HOBBIES_PER_PAGE = 6;
}
