@extends('layouts.app')

@section('content')
    <admin-page></admin-page>
@endsection
