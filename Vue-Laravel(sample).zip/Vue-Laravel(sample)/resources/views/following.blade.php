@extends('layouts.app')

@section('content')
    <following-page user_id="{{ $id }}"></following-page>
@endsection
