@extends('layouts.app')

@section('content')
    <comments-page hobby_id="{{ $id }}"></comments-page>
@endsection
