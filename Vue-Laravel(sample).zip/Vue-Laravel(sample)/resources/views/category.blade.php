@extends('layouts.app')

@section('content')
    <category-page id="{{ $id }}"></category-page>
@endsection
