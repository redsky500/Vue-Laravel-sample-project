@extends('layouts.app')

@section('content')
    <followers-page user_id="{{ $id }}"></followers-page>
@endsection
