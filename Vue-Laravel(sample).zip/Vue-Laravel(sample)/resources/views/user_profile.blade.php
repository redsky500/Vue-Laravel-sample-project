@extends('layouts.app')

@section('content')
    <user-page username="{{ $username }}"></user-page>
@endsection
