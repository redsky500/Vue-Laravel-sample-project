<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-auto text-center">
                <div class="welcome-div">
                    Welcome!
                </div>
                <em>Click on the button below to share your hobbies,<br>
                or browse the different categories and start following people!</em>
                <br><br>
            </div>
        </div>

        <post-new-hobby></post-new-hobby>
        <br><br><br><br>
    </div>
</template>

<style scoped>
    .welcome-div {
        color: #2b7cce;
        font-family: "Strait";
        font-size: 6em;
    }
</style>
